public class new2a
{
	public static void main(String args[])
	{
		int x = 1;
		System.out.println((x*=2) + (x*=4));
	}
}