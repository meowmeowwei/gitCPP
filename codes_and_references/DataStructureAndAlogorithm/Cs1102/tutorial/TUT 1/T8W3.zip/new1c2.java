public class new1c2
{
	public static void objectComeIn(Object object)
	{
		System.out.println(object);
	}
	public static void integerComeIn(Integer integer)
	{
		System.out.println(integer);
	}

	public static void main(String args[])
	{
		objectComeIn(5);
		objectComeIn(new Integer(5));
		integerComeIn(5);
		integerComeIn(new Integer(5));
	}
}