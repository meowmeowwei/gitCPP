import java.util.*;

public class new1c1
{
	public static void main(String args[])
	{
		//ArrayList al = new ArrayList<int>(20);
		ArrayList al = new ArrayList<Integer>(20);
	}
}